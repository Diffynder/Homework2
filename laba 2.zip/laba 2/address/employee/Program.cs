﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee1 = new Employee("работни1", "Андрей", "юрист", 1000);
            Employee employee2 = new Employee("работник2", "Валерий", "программист", 1500);
            Employee employee3 = new Employee("работник3", "Сергей", "экономист", 1800);
            employee1.MethodInfo();
            employee2.MethodInfo();
            employee3.MethodInfo();
            Console.ReadKey();
        }
    }
    class Employee
    {
        public string SurName { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public int Experience { get; set; }
        public Employee(string surname, string name, string position, int exp)
        {
            this.SurName = surname;
            this.Name = name;
            this.Position = position;
            this.Experience = exp;
        }
        public void Method()
        {
            int salary = 0;
            if (Position == "юрист")
            {
                salary += 1000;
            }
            else if (Position == "экономист")
            {
                salary += 1500;
            }
            else if (Position == "программист")
            {
                salary += 1800;
            }
            Console.WriteLine($"Salary = {salary} $");
        }
        public void MethodInfo()
        {
            Console.WriteLine($"{SurName}, {Name}, {Position},{Experience}");
            Method();

        }
    }
}
