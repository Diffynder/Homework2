﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace address
{
    class Program
    {
        static void Main(string[] args)
        {
            Address address = new Address();
            address.Index = 33333;
            address.Country = "France";
            address.City = "Paris";
            address.Street = "FirstStreet";
            address.House = "A";
            address.Apartment = 5;
            address.Print();
            Console.ReadKey();
        }
    }

    class Address
    {
        private int index;
        private string country;
        private string city;
        private string street;
        private string house;
        private int apartment;


        public int Index
        {
            get => index;
            set => index = value;
        }

        public string Country
        {
            get => country;
            set => country = value;
        }

        public string City
        {
            get => city;
            set => city = value;
        }

        public string Street
        {
            get => street;
            set => street = value;
        }

        public string House
        {
            get => house;
            set => house = value;
        }

        public int Apartment
        {
            get => apartment;
            set => apartment = value;
        }

        public void Print()
        {
            Console.WriteLine("Index: " + Index);
            Console.WriteLine("Country: " + Country);
            Console.WriteLine("City: " + City);
            Console.WriteLine("Street: " + Street);
            Console.WriteLine("House: " + House);
            Console.WriteLine("Apartment: " + Apartment);
        }
    }
}
