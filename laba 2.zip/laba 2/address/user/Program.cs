﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace user
{
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User("login", "Anton","Antonov", 34);
            user.Info();
           
            Console.ReadKey();
        }
    }
    class User
    {
        private  string login;
        private string name;
        private string surname;
        private int age;
        private readonly DateTime registrationDate;


        public User(string login, string name, string surname, int age)
        {
            registrationDate = DateTime.Now;
            this.login = login;
            this.name = name;
            this.surname = surname;
            this.age = age;
        }

        public void Info()
        {
            Console.WriteLine(
                $"Login: {login}, name: {name}, surname: {surname}, age: {age}, registration date: {registrationDate}");
        }
    }
}
